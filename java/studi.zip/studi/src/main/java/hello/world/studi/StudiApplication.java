package hello.world.studi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudiApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudiApplication.class, args);
	}

}
